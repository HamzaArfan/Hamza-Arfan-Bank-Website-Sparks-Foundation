<?php
require './db_conn.php';

if(isset($_POST["submit"]))
{
    
	$id = $_POST['cid1'];
	$ccid = $_POST['cid2'];
	$ammount = $_POST['amount'];

    $servername = "localhost";
			$username = "root";
			$password = "";
			$database = "bankproject";

			// Create connection
			$connection = new mysqli($servername, $username, $password, $database);

            // Check connection
			if ($connection->connect_error) {
				die("Connection failed: " . $connection->connect_error);
			}

            $sql = "SELECT * FROM customer_data where customer_data.cid='$id'";
            $result = $connection->query($sql);
    
    
            // read data of each row
        $row = $result->fetch_assoc();

        $ciid1=$row["amount"];
   $c1=$ciid1-$ammount;


   $sql = "SELECT * FROM customer_data where customer_data.cid='$ccid'";
   $result2 = $connection->query($sql);

   
   // read data of each row
$row2 = $result2->fetch_assoc();
$cid2=$row2["amount"];
$c2=$cid2+$ammount;
	
	
		
		
		
        $query = "UPDATE customer_data
        SET amount = '$c2'
        WHERE cid = '$ccid'";

	$query2 = "UPDATE customer_data
    SET amount = '$c1'
    WHERE cid = '$id'";

		
        		if(mysqli_query($conn, $query))
		{
            if(mysqli_query($conn, $query2))
			header("Location:maketransaction.php");
		} else {
			echo "
			<script> alert('Error: " . mysqli_error($conn) . "'); </script>
			";
		}


      
	

}
?>







































<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction</title>
</head>
<body>
    <link rel="stylesheet" href="maketransaction1.css">
   <div class="transactionheader">
<img src="pngwing.com (1).png" style="width: 40px; height: 40px;">
<h1 style="margin-left: 5px;">
    Quantum Finances
</h1>
   </div> 
    
<div class="headertext">
<h1>
    Make A Transaction
</h1>
</div>
<form action="" class="" method="post">
<div class="row" style="width:100%;height:200px;">
    <div class="coloumn">
        <label for="TransactionFrom">Transaction From</label>
    <div class ="inputs">
      <input type="text" class="inputfeild" placeholder="Customerid"  name="cid1" id="cid1">
    </div>
    </div>
    <div class="coloumn">
  <Label for="TransactionTo" style="margin-left: 10px;">Transaction To</Label>
    <div class="inputs">
    <input type="text" class="inputfeild" style="width: 160px;" placeholder="Customerid" name="cid2" id="cid2">
    </div>


</div>
<div class="coloumn">
    <Label for="TransactionTo"> Transfer Amount</Label>
      <div class="inputs">
      <input type="text" class="inputfeild" style="width: 160px;" placeholder="Enter Amount"  name="amount" id="amount">
    </div>
</div>

</div>
<div>
    <input type="submit" value="Transfer" class="transferbutton" name="submit">
</div>
</form>
</body>
</html>