
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body >



<table class="table table-hover table-center">
									<thead>
			<tr>
								
				<th>Customer ID</th>
				<th>Customer Name</th>
				<th>Amount</th>

			</tr>
		</thead>

        <tbody>
            <?php
            $servername = "localhost";
			$username = "root";
			$password = "";
			$database = "bankproject";

			// Create connection
			$connection = new mysqli($servername, $username, $password, $database);

            // Check connection
			if ($connection->connect_error) {
				die("Connection failed: " . $connection->connect_error);
			}


			$sql = "SELECT * FROM customer_data";
			$result = $connection->query($sql);

            if (!$result) {
				die("Invalid query: " . $connection->error);
			}

            // read data of each row
			while($row = $result->fetch_assoc()) 
            {
                echo "<tr>
                    <td>" . $row["cid"] . "</td>
                    <td>" . $row["cname"] . "</td>
                    <td>" . $row["amount"] . "</td>
                </tr>";
            }

            $connection->close();
            ?>
        </tbody>

			</table>


    
</body>
</html>
