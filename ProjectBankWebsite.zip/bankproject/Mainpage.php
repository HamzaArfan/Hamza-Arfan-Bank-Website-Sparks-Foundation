<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quantum Finance</title>
</head>
<link rel="stylesheet" href="Mainpage1.css">
<body > 

<div class="img_container">
    <img class="image1"; src="pngwing.com (1).png" style="width: 35px;height: 35px;">
    <div class="container">
        <h1 >Quantum Finance</h1>
        <div class="buttons">
          <button class="button" onclick="location.href='Aboutus.html';" >About Us</button>
          <button class="button" onclick="location.href= 'customerdata.php';">Customer Table</button>
          <button class="button" onclick="location.href='maketransaction.php';">Make Transactions</button>
        </div>
      </div>
    </div>

    <div class="heading">
        <h1 style="align-content: center;">
            Welcome To Quantum Finance
        </h1>
    
    </div>
    <br>
    <br>


<div class ="Headingimages">
<img src="pngwing.com (1).png" style="width: 100px;height: 100px;"class="imagesinfo">
<img src="pngwing.com (2).png" style="width: 100px;height: 100px;"class="imagesinfo">
<img src="pngwing.com (3).png" style="width: 100px;height: 100px;"class="imagesinfo">
<img src="pngwing.com (5).png" style="width: 100px;height: 100px;"class="imagesinfo">
<img src="pngwing.com (6).png" style="width: 100px;height: 100px;"class="imagesinfo">
<br>
<br>
<img src="pngwing.com (7).png" style="width: 100px;height: 100px;"class="imagesinfo">
<img src="pngwing.com (8).png" style="width: 100px;height: 100px;"class="imagesinfo">
<img src="pngwing.com (9).png" style="width: 100px;height: 100px;"class="imagesinfo">
<img src="pngwing.com (10).png" style="width: 100px;height: 100px;"class="imagesinfo">
<img src="pngwing.com (11).png" style="width: 100px;height: 100px;"class="imagesinfo">

</div>


<br>
<br>
<br>
<br>
<div class="paragraphs">
    <h3>
      We Work On All Kinds Of Crypto Currencies And Web3 Technologies
    </h3>
    </div>
    <br>
    <br>
<div class="row">

    <h2 id="features">Our Features</h2>
    <br>
    <br>
    <div class="coloumn" style="color: aquamarine;">
     <img src="man.png" style="width: 150px;height: 150px;">
     <br>
    <div class="row">
     <button id="clickbutton" onclick="location.href='Aboutus.html'"  style="margin-left:30px;font-size: larger;font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;"> About Us</button>
    </div>
    </div>
    
    <div class="coloumn" style="color: aqua;">
        <img src="service.png"style="width: 150px;height: 150px;">
        <div class="row">
            <button id="clickbutton" style="font-size: larger;font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;"> Our Customers</button>

        </div>

    
    </div>

    <div class="coloumn" style="color: aquamarine;">
        <img src="card-payment.png" style="width: 150px;height: 150px;">
        <div>
            <button id="clickbutton" onclick="location.href='maketransaction.php';" style="font-size: larger;font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;"> Do Transaction</button>

        </div>
    
    </div>
    
    <div class="coloumn" style="color: aqua;">
    
    </div>

</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<div class="homeend">
<div class="imagelast">
<img src="pngwing.com (1).png" style="width:120px;height:120px">
</div>
<p id="lasttext1" style="font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif; margin-top: -5px;margin-left: 645px;"> All Copy Rights & Claims. </p>
<p id="lasttext2" style="font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;font-weight: 300;margin-top:-15px;margin-left: 670px;"> Quantum Finances </p>
<p id="lasttext2" style="font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;font-weight: 300;margin-top:35px;margin-left: 610px;"> Gmail: QuantumFinances@gmail.com </p>
<p id="lasttext2" style="font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;font-weight: 300;margin-top:-15px;margin-left: 624px;"> Address: Nyc Steet15,Silicon Valey </p>
</div>

</body>
</html>